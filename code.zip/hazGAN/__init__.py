from .utils import *
from .data import *
from . import plotting

# from .tensorflow import *
# from . import conditional
# from .R import R
# from .statistics import *
# from .xarray import *

__version__ = "2.02"
__author__ = "Alison Peard (alison.peard@gmail.com)"
